<?php
// Heading 
$_['heading_title']     	  = 'Sell';

//Text
$_['text_tax']     	   		  = 'Tax : ';
$_['text_from']     	      = 'From ';
$_['text_seller']     	      = 'Seller ';
$_['text_total_products']     = 'Total Products ';
$_['text_long_time_seller']   = 'Long Time Sellers';
$_['text_latest_product']     = 'Latest Products';

?>
